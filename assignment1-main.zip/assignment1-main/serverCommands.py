from utility import *
'''
File contains methods which execute the client's commands.

By this point the command has been confirmed to be valid
and the command may be executed.
'''

def executeExit(connectionSocket):
	connectionSocket.close()

# Method sends available open filenames to the client

# If a key was entered, it sends the filenames protected
# by that key in addition to the open filenames
def executeQuery(connectionSocket, commandTokens):
	filename = commandTokens[1]
	key = commandTokens[2]

	final = ""
	openFiles = getFileLines("open_files.txt")
	for line in openFiles:
		final = final + line.strip() + ","

	final = final[:-1]
	if (key != "#"):
		final = final + "|"
		keyFiles = getFileLines(key+".txt")
		for line in keyFiles:
			final = final + line.strip() + ","
		final = final[:-1]

	message = final
	connectionSocket.send( message.encode() )


# Method sends requested file to the client

# Server first waits for confirmation that the client is
# ready to receive the file.

# A hashcode is sent as well to confirm that the file 
# received by the client is identical to the one the
# server sent

def executeGet(connectionSocket, commandTokens):
	filename = commandTokens[1]
	key = commandTokens[2]


# Method receives file sent by the client

# Server first sends confirmation that it is ready to receive
# the file.

# A hashcode is received as well to confirm that the file 
# received by the server is identical to the one the client
# sent
def executePost(connectionSocket, commandTokens):
	filename = commandTokens[1]
	key = commandTokens[2]