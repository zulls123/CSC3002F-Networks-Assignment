from data_transfer import *
import socket
import sys
import os


'''
Receives the the query string from the server, parses it
and prints it in a more readable fashion
'''
def executeQuery(socket):
	queryResult = receiveQueryString(socket)
	splitResult = queryResult.split("|")
	print()
	isOpen = False
	isProtected = False
	for i in splitResult:

		if (isOpen):
			openFiles = i.split(",")
			openFiles.sort()
			for f in openFiles:
				if (f != ""):
					print("open       ",f)
			isOpen = False

		elif (isProtected):

			protectedFiles = i.split(",")
			protectedFiles.sort()

			for f in protectedFiles:
				if (f != ""):
					print("protected  ",f)
			isProtected = False
		
		if ( i == "o"):
			isOpen = True
		elif ( i == "p"):
			isProtected = True
	print()

'''
Sends a file to the server
'''
def executePost(socket, filename):
	print("Sending file")
	response = sendFile(socket, filename)
	
	response = response.split("|")
	if (response[0] == "OK"):
		print("File was received")
	else:
		print("File not received correctly. Try again")

'''
Downloads a file from the server
'''
def executeGet(socket, filename):
	print("Getting file")
	if (receiveFile(socket, filename)):
		print("File received")
	else:
		print("File not received correctly. Try again")


'''
Connects to the server and sends a command to it. This method is
called each time that the client requests a command to be executed. 
'''
def sendCommand(command, ip, port):
	
	clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
	clientSocket.connect( (ip, port) )

	commandSplit = command.split(" ")
	clientSocket.send( command.encode() )

	commandValidity = clientSocket.recv(1024).decode()
	commandValidity = commandValidity.split("|")
	status = commandValidity[0]

	if (status == "BAD"):
		errorMessage = commandValidity[1]
		print(errorMessage)

	else:
		commandType = commandValidity[1]
		if 	(commandType == "GET"):
			filename = commandSplit[2]
			executeGet(clientSocket, filename)

		elif (commandType == "POST"):
			filename = commandSplit[2]
			executePost(clientSocket, filename)
			
		elif (commandType == "QUERY"):
			executeQuery(clientSocket)

		

def main():
	try:
		serverIP = sys.argv[1]
		serverPort = int(sys.argv[2])
	except Exception:
		print("Please run with command line arguments")
		exit()


	while True:
		os.system('cls' if os.name == 'nt' else 'clear')
		print("You have connected to networks_waffle\n"+"IP: "+serverIP+"\nPort: "+str(serverPort)+"\n")
		print("Commands available:") 
		print("\t- GET <privacy> <filename> <key if privacy == p> ")
		print("\t- GETMANY <file1,file2,file3>\n\t\t- only available for open files")
		print("\t- POST <privacy> <filename> <key if privacy == p> ")
		print("\t- POSTMANY <file1,file2,file3>\n\t\t- only available for open files")
		print("\t- QUERY <privacy> <filename> <key if privacy == p or a>")
		print("\t- EXIT")
		print("\n - Files to be uploaded should be stored in same directory as client code")
		print(" - Privacy 'o', means open. Privacy 'p' means protected")
		print(" - QUERY has special privacy 'a', which includes open and protected")
		print("")

		command= input("Enter a command\n")
		commandSplit = command.split(" ")
		commandType = commandSplit[0]
		try:
			# GET and QUERY commands may immediately be sent to the sendCommand method
			if (commandType== "GET" or commandType == "QUERY"):
				sendCommand(command, serverIP, serverPort)

			elif (commandType == "EXIT"):
				break

			elif (commandType== "POST"):
				# POST is in try catch in case the file does not exist
				try:
					sendCommand(command, serverIP, serverPort)
				except OSError:
					print("File not found in your directory")
					input("Enter any key to continue\n")
					continue

			elif (commandType == "GETMANY"):
				template = "GET o "	#template for making the GET commands
				if (len(commandSplit) == 2 ):
					files = commandSplit[1].split(",")

					for file in files:
						print("GET-ting",file)
						command = template + file
						sendCommand(command, serverIP, serverPort) #sends individual commands to the server
						print("")

				else:
					print("GETMANY requires 2 parameters")
					input("enter any key to continue\n")
					continue

			elif (commandType == "POSTMANY"):
				template = "POST o " #template for making the GET commands
				if (len(commandSplit) == 2 ):
					files = commandSplit[1].split(",")

					for file in files:
						print("POST-ing",file)
						command = template + file
						try:
							sendCommand(command, serverIP, serverPort) #sends individual commands to the server
						except OSError:
							print("File not found in your directory")
						print("")

				else:
					print("POSTMANY requires 2 parameters")
					input("enter any key to continue\n")
					continue

			else:
				print("Please enter a valid command")
				input("enter any key to continue\n")
				continue

			input("Enter any key to continue\n")


		except socket.error as e:
			print("You have unexpectedly lost connection or are unable to connect to the server")
			while True:
				choice = input("Enter 'q' to leave or 'c' to try reconnecting:\n")
				if (choice == 'q'):
					exit()
				elif (choice == 'c'):
					break


	print("Goodbye")
		
		
if __name__ == "__main__":
	main()