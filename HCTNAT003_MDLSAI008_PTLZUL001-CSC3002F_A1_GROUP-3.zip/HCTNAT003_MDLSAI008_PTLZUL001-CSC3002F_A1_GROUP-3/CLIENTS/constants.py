'''
Constants that are used throughout the server's scripts
'''
PRIVATE = "p"
PUBLIC 	= "o"
PUBLIC_AND_PRIVATE = "a"
DELIM 	= "|"
MINOR_DELIM = ","
GOOD_CODE = "OK"
BAD_CODE = "BAD"