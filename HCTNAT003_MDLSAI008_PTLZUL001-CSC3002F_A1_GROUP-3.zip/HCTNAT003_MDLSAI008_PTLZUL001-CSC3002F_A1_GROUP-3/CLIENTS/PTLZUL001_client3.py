from data_transfer import *
import socket
import sys
import array

def Welcome_Message():
    print ("Welcome to the Networks-Waffle server:\n") 
    print("These are the commands which can be used for different functions from the server:\n")
    print("The different types of privacies are: 'o' (open), 'p'(protected) and 'a'(protected and open files)\n")
    print("To access files with a specific privacy mode please use the allocated letter(a,o,p)\n")
    print("If privacy = o - no key is required, else a key is required to be entered\n")
    print("\n")
    print("The commands are: \n")
    print("GET <privacy> <filename> <key>")
    print("POST <privacy> <filename> <key>")
    print("QUERY <privacy> <key>")
    print("EXIT: to leave the server\n")


def main():
    try:
        #taking input from command line
        serverIP = sys.argv[1]
        serverPortNum = int(sys.argv[2])
    except Exception:
        print("Please try running with command-line arguments")
        exit()


    #welcome message
    Welcome_Message()

    #for reading in commands and file transfer
    while True:
        #exception handling
        try:
            clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            #connect client to server
            clientSocket.connect((serverIP, serverPortNum))

            #prompt the client to enter commands
            print("Enter a command from our command list specified:\n")

            #store the client's command
            clientCommand = input("")
            #split command to get it's contents
            commandTokens = clientCommand.split(" ")
            #send the command to the server
            clientSocket.send(clientCommand.encode())


            #       COMMAND VALIDATION
            commandCheck = clientSocket.recv(1024).decode()
            commandCheckTokens = commandCheck.split("|")

            #used to print the status of the commands
            status = commandCheckTokens[0]

            if(commandCheckTokens[0] == "BAD"):
                messageError = commandCheckTokens[1]
                print(messageError)

            #   COMMAND EXECUTION
            else:
                command = commandCheckTokens[1]
                #switch case
                

                    
                #for downloading of a file
                if(command == "GET"):
                    #send message to client
                    print("Retrieving the file...")

                    #if file is not retrieved correctly
                    
                    if (not receiveFile(clientSocket, commandTokens[2])):
                        print("The file was not correctly downloaded. Please retry.")
                    else:
                        print("Thank you. The file has been downloaded.")
                
                #for uploading of a file
                elif (command == "POST"):

                    print("Uploading file...")

                    #send the file to the server
                    try:
                        response = sendFile(clientSocket, commandTokens[2])
                    except OSError:
                        print("The file you requested to upload was not found in your directory.")
                        continue

                    responseParameters = response.split("|")
                    if(responseParameters[0] == "OK"):
                        print("Thank you for uploading. The file has been received.")
                    else:
                        print("The file was not uploaded correctly. Please retry.")

                #for listing of available files
                elif (command == "QUERY"):
                    output = receiveQueryString(clientSocket)
                    outputTokens = output.split("|")
                    privacy = outputTokens[0]
                    file_ns = outputTokens[1].split(",")
                    for i in range (0, len(file_ns)):
                        print(privacy + "\t" + file_ns[i])
                   
                    if (len(outputTokens) > 2):
                        privacy = outputTokens[2]
                        file_ns = outputTokens[3].split(",")
                        for i in range (0, len(file_ns)):
                            print(privacy + "\t" + file_ns[i])
                        
                        
                #for client to exit the server
                elif(command == "EXIT"):
                    print("You have been exited from the server.")
                    #end program
                    break
        except socket.error as e:
            #for unexpected loss of connection from the server
            print("You have unexpectedly lost connection or are unable to connect to the server at this time.")
            #while connection is lost
            while True:
                option = input("Enter 'q' to exit or 'rec' to reconnect to the server.")
                if(option == "q"):
                    exit()
                elif(option=="rec"):
                    break


if __name__ == "__main__":
	main()


    


            



