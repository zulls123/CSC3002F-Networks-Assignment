import socket
import hashlib
from constants import *
'''
Contains methods related to receiving and sending potentially long
sets of data. These methods allow the receiver to be sure that
they have received the entire set of data.
'''


'''
Method sends a potentially long string to the receiver. It is
specifically used for the sending of the Query string.

It sends the receiver the length of the data it will be sending
before sending the actual data
'''
def sendQueryString(socket, queryString):
	queryString = queryString.encode()
	dataLength = len(queryString)

	socket.send(str(dataLength).encode()) 	
	socket.recv(1024).decode() 		#receive confirmation that the length was received

	socket.sendall(queryString)  			
	socket.recv(1024).decode 		#receive confirmation that the string was received



'''
Method receives a potentially long string from a sender. It is
specifically used for the receiving the Query string.

It receives the length of the data before receiving the actual
data. It receives data in a loop and only stops once the length
of the data it has received is equal to the length of the data
it was told it would be receiving
'''
def receiveQueryString(socket):
	totalDataLength = int( socket.recv(1024).decode() )
	socket.send(GOOD_CODE.encode())		#send confirmation that length was received
	
	# ends loop once it has received the total length of data
	dataReceivedLength 	= 0
	completeData 		= b""	
	while( dataReceivedLength != totalDataLength):
		data = socket.recv(1024)
		dataReceivedLength += len(data)
		completeData += data 

	socket.send(GOOD_CODE.encode())		#send confirmation that string was received

	return completeData.decode()



'''
Method sends a file to a receiver.

It sends the receiver the length of the data as well as a hash
of the data before sending the actual data

Returns a message received from the receiver indicating
whether the file was corrupted or not on the receiving end.
'''
def sendFile(socket, filename):
	file = open(filename, 'rb') 	#opening and reading the file data in binary
	data = file.read()
	file.close()

	fileHash = hashlib.sha256(data).hexdigest()		#hashing the file data
		
	fileLength = len(data) 
	socket.send( str(fileLength).encode())
	socket.recv(1024).decode()		#receive confirmation that the length was received

	socket.send( fileHash.encode() )
	socket.recv(1024).decode()		#receive confirmation that the hash was received


	socket.sendall(data)

	#receive status regarding whether the file was corrupted or not
	sendStatus = socket.recv(1024).decode()

	return sendStatus



'''
Method receives a file from a sender.

It receives the length of the data as well as a hash
of the data before receiving the actual data.

It receives data of the file in a loop and only stops once the 
length of the data it has received is equal to the length of the 
data it was told it would be receiving.

It hashes the data it received and compares it to the hash
it received from the sender to check for corruption.

Returns true if file was not corrupted
'''
def receiveFile(socket, filename):
	totalDataLength = int( socket.recv(1024).decode() )
	socket.send(GOOD_CODE.encode())		#send confirmation that length was received

	senderFileHash =  socket.recv(1024).decode()
	socket.send(GOOD_CODE.encode())		#send confirmation that hash was received
	
	# ends loop once it has received the total length of data		
	dataReceivedLength 	= 0
	completeData 		= b""
	while( dataReceivedLength != totalDataLength):
		data = socket.recv(1024)
		dataReceivedLength += len(data)
		completeData += data 

	receiverFileHash = hashlib.sha256(completeData).hexdigest() # hashing the file data received

	# if file received is not corrupted
	if (senderFileHash == receiverFileHash):
		file = open(filename, "wb")
		file.write( completeData )
		file.close()
		status = GOOD_CODE+DELIM+"DONE"
		socket.send( status.encode() )
		return True

	else:
		status = BAD_CODE+DELIM+"File not sent correctly. Try again"
		socket.send( status.encode() )
		return False