import sys
from socket import *
from data_transfer import *

# receive query request result as a string, parse and print open filenames 
def open(files):
    files = files[2: len(files)] #remove privacy flag
    output = files.split(',')
    print('List of OPEN files:\n')
    for i in output:
        print(i)

# receive query request result as a string, parse and print protected filenames
def protected(files):
    files = files[2: len(files)] #remove privacy flag
    output = files.split(',')
    print('List of PROTECTED files:\n')
    for i in output:
        print(i)

# receive query request result as a string, parse and call relevant methods to print open and protected filenames separately		
def all(files):
    output = files.split('|p|') #separate open and protected filenames
    open(output[0])
    print('')
    temp = 'p|' + output[1]
    output[1] = temp
    protected(output[1])

def main():
    try:
        address = sys.argv[1]
        port = int(sys.argv[2])
    except Exception as e: # command line arguments not specified
         print('Oops! Did you forget something :(')
         print('Hint: specify the IP address & port number of the server ;)')  
         exit()

    print('Hi there! :)')
    menu = """Enter a request or "EXIT" to close, and press return:
    1. QUERY (o,p,a) <key>
        - QUERY o
        - QUERY p <key>
        - QUERY a <key>

    2. (GET,POST) (o,p) filename <key>
        - GET o filename
        - GET p filename <key>
        - POST o filename
        - POST p filename <key>\n"""

    while True:
        try:
            mySocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            mySocket.connect((address, port))

            request = input(menu)
            requestParams = request.split(" ")
            mySocket.send(request.encode())

            result = mySocket.recv(1024).decode() # communication from server regarding validity of request (no. of parameters, etc.)
            resultParams = result.split("|")

            if (resultParams[0] == 'BAD'): # request invalid
                print('Error: ' + resultParams[1])
            else:
                if (resultParams[1] == 'QUERY'):
                    s = receiveQueryString(mySocket) # string of filenames which are open or protected by the given key
                    if (requestParams[1] == 'o'):
                        open(s)
                    elif (requestParams[1] == 'p'):
                        protected(s)
                    elif (requestParams[1] == 'a'):
                        all(s)
                elif (resultParams[1] == 'POST'):
                    print('Just a second ... sending the specified file ...')
                    try:
                        sent = sendFile(mySocket, requestParams[2])
                    except OSError: # the specified file is not in the current directory
                        print('Oops! Are you sure about the location of this file?')
                        continue
                    sentParams = sent.split("|")
                    if (sentParams[0] == 'OK'): # file sent correctly
                        print('All done!')
                    else:
                        print('Oops! The specified file could not be sent ... try again ...')
                elif (resultParams[1] == 'GET'):
                    print('Just a second ... fetching the requested file ...')
                    if (not receiveFile(mySocket, requestParams[2])):
                        print('Oops! The requested file could not be fetched ... try again ...')
                    else: # file received correctly
                        print ('All done!')
                elif (resultParams[1] == "EXIT"):
                    print("Goodbye!")
                    mySocket.close()
                    break
    
        except error as e: # client tries to connect before server is running
            print('Oops! Something went wrong :(')
            while True:
                option = input('Enter "CONT" to try again or "QUIT" to close, and press return:\n')
                if (option == 'QUIT'):
                    exit()
                elif (option == 'CONT'):
                     break

if __name__ == "__main__":
	main()
