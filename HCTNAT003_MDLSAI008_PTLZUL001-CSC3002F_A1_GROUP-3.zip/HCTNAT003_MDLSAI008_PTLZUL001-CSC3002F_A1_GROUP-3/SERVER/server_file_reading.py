from constants import *
'''
Methods related to reading the text files responsible for keeping
track of the files stored on the server.

These files include the "protected.txt" and the "open.txt" files
'''


'''
This method searches for the "checkFor" string within the file
that was input.

returns a boolean. True if the string was found in the file
'''
def isStringInFile( filename, checkFor ):
	file = open( filename, "r")
	fileLines = file.readlines()
	file.close()

	result = False
	for f in fileLines:
		if (checkFor == f.strip()):
			result = True
			break
	return result

'''
This method returns the line containing the string, "string",
within the file, filename. Returns the line as an array.

Because the protected.txt file has more than one piece of
information stored in it, index is used to specify which
postion the information who are searching for is stored
in.
'''
def getLineWithString(filename, string, index):
	file = open( filename, "r")
	fileLines = file.readlines()
	file.close()

	for f in fileLines:
		currentLine = (f.strip()).split("|")
		if (len(currentLine) > 1 and currentLine[index] == string):
			return currentLine
	return []


'''
This method returns an array containing all the lines within
the file that was input
'''
def getFileLines( filename ):
	file = open( filename, "r")
	fileLines = file.readlines()
	file.close()
	return fileLines


'''
This method finds returns all filenames applicable to the QUERY command
that was entered.
'''
def getQueryString(commandTokens):
	privacy = commandTokens[1]

	final = ""

	# This if statement body adds all open files to the final string
	if (privacy == PUBLIC_AND_PRIVATE or privacy == PUBLIC):

		final = final + PUBLIC + DELIM 	# added to make parsing easier for client
		openFiles = getFileLines("open.txt")

		for line in openFiles:
			final = final + line.strip() + MINOR_DELIM	# strip() removes \n at the end of line read
			

		final = final.strip(MINOR_DELIM)

	# This if statement body adds all protected files to the final string
	if (privacy == PUBLIC_AND_PRIVATE or privacy == PRIVATE):
		if (privacy == PUBLIC_AND_PRIVATE):
			final = final + DELIM
		final = final + PRIVATE + DELIM # added to make parsing easier for client
		protectedFiles = getFileLines("protected.txt")
		key = commandTokens[2]

		for line in protectedFiles:
			line = line.strip() 
			tokens = line.split(DELIM)

			# only adds filename if protected by the entered key to the final string
			if (tokens[1] == key):
				final = final + tokens[0] + MINOR_DELIM

	final = final.strip(MINOR_DELIM)
	return final