import socket
import sys
import server_checks
import data_transfer
import server_file_reading
from constants import *

'''
Main method which runs a file storage server which one client can 
connect to at a time. Server provides the client with commands to
download a file, upload a file and query what files are available.

Files may be in an open or protected state. Protected files can only
be downloaded or queried if the client provides the file's key. 
	- A key functions as a password

If the server encounters any errors while running, the appropriate
error along with explanation is sent to the client.
'''


'''
Helper method to call the appropriate Check method for the command
entered. The check commands can be found in the serverChecks.py file
'''
def getCheckResponse(commandTokens):
	commandStatus = ""
	commandCode = commandTokens[0]

	if ( commandCode == "EXIT"):
		commandStatus = server_checks.getExitCheckResponse(commandTokens)

	elif ( commandCode == "GET"):
		commandStatus = server_checks.getGetCheckResponse(commandTokens)

	elif ( commandCode == "QUERY"):
		commandStatus = server_checks.getQueryCheckResponse(commandTokens)

	elif ( commandCode == "POST"):
		commandStatus = server_checks.getPostCheckResponse(commandTokens)

	else:
		commandStatus = BAD_CODE+DELIM+"Invalid command"

	return commandStatus

'''
Helper method to call the appropriate methods for the execution of 
a command entered.
'''
def executeCommand(connectionSocket, commandTokens):
	commandCode = commandTokens[0]

	if ( commandCode == "QUERY"):
		queryString = server_file_reading.getQueryString(commandTokens)
		data_transfer.sendQueryString(connectionSocket, queryString)

	elif ( commandCode == "GET"):
		filename = "files/"+commandTokens[2]

		status = data_transfer.sendFile(connectionSocket, filename)
		statusTokens = status.split("|")

		if (statusTokens[0] == BAD_CODE):
			print("File sent corrupted ")
		
	elif ( commandCode == "POST"):
		filename = "files/"+commandTokens[2]

		if (data_transfer.receiveFile(connectionSocket, filename)):

			if (commandTokens[1] == "o"):
				file = open("open.txt", "a")
				file.write(commandTokens[2]+"\n")
				file.close()

			else:
				file = open("protected.txt", "a")
				file.write(commandTokens[2]+"|"+commandTokens[3] +"\n")
				file.close()
		else:
			print("File received corrupted")


'''
Method returns the internet ipv4 ip address. It connects to a public
DNS server and extracts the IP address used by the machine to connect
to the DNS server. No messages are exchanged with the DNS server
'''
def getIpAddress():
	tempSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	tempSocket.connect(("208.67.222.222", 7000))

	addressPortTuple = tempSocket.getsockname()
	tempSocket.close()

	return addressPortTuple[0]

'''
Prints the command line instructions required in order to run the
server properly
'''
def commandLineInstructions():
	print("Please run with correct command line arguments")
	print("use 'loc' if server and client will be run on the same machine")
	print("use 'net' if server and client will be run on different machines")
	exit()

def main():
	serverIp = ""
	try:
		if (sys.argv[1] == "con"):
			serverIp = getIpAddress()
		elif (sys.argv[1] == "loc"):
			serverIp = socket.gethostbyname( socket.gethostname() )
		else:
			commandLineInstructions()

	except Exception:
		commandLineInstructions()

	# server setup
	serverPort = 7777
	serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	serverSocket.bind( (serverIp, serverPort) )

	serverSocket.listen(10)		# server listens for up to 10 clients

	# prints ip and port number for clients to connect with
	print("networks_waffle started!")
	print("Server IP: " +serverIp)
	print("Server port: " +str(serverPort))

	# the server continues to run forever and has no exit condition

	while True:

		try:
			connectionSocket, connectionAddress = serverSocket.accept() # lets client join the server
			clientIp = connectionSocket.getsockname()[0]
			print()	# prints an empty line to indicate when the next client is being helped
			print(clientIp + " is sending a command")

			clientCommand = connectionSocket.recv(1024).decode()	# receives client's command
			
			commandTokens = clientCommand.strip().split(" ")
			commandCode = commandTokens[0]
			
			commandStatus = getCheckResponse(commandTokens)		# checks if client's command is valid
			
			connectionSocket.send( commandStatus.encode() )		# sends client message indicating if command was valid
			
			commandStatusTokens = commandStatus.split("|")
			if ( commandStatusTokens[0] == BAD_CODE):
				# if the command was invalid, the command is not executed
				print(clientIp + " sent an invalid command")

			else:
				print(clientIp + " sent a valid command")

				# only enters the if statement body if the command
				# is not an EXIT command 
				if ( not (commandStatusTokens[1] == "EXIT") ):
					print(clientIp, commandStatusTokens[1],"command is being executed")
					executeCommand(connectionSocket, commandTokens)
			
			# connection with client is closed immediately after a command
			# has been processed to completion
			connectionSocket.close()
			print(clientIp + " is done")

		except (socket.error, ValueError) as e:
			# catches situations where the client tries to send a file
			# that does not exist in their directory and when the client
			# loses connection with the server
			print(clientIp + " unexpectedly lost connection")
			

if __name__ == "__main__":
	main()