import server_file_reading
from constants import *
'''
Contains methods used to check whether the command sent by the
client is valid or not. The methods create an appropriate 
COMMAND MESSAGE to send to the client based on whether the command 
is valid or not

Each command has its own set of checks to check due to their
differing nature. 
'''


'''
Checks whether an EXIT command is valid or not

Returns the COMMAND MESSAGE to be sent to the client
'''
def getExitCheckResponse(clientCommandTokens):
	if (len(clientCommandTokens) != 1):
		return BAD_CODE+DELIM+"EXIT command should have no parameters"
	else:
		return GOOD_CODE+DELIM+"EXIT"

'''
Checks whether the GET command sent by the client is valid

Returns the COMMAND MESSAGE to be sent to the client
'''
def getGetCheckResponse( clientCommandTokens):
	if (len(clientCommandTokens)<3):
		return BAD_CODE+DELIM+"GET requires more parameters"

	filename = clientCommandTokens[2]
	privacy = clientCommandTokens[1]

	if (privacy == PUBLIC):
		if (len(clientCommandTokens) != 3):
			return BAD_CODE+DELIM+"Public GET requires 3 parameters"

		elif (server_file_reading.isStringInFile("open.txt", filename)):
			return GOOD_CODE+DELIM+"GET"
		else:
			return BAD_CODE+DELIM+"File does not exist on the server"

	elif (privacy == PRIVATE):
		if (len(clientCommandTokens) != 4):
			return BAD_CODE+DELIM+"Private GET requires 4 parameters"

		enteredKey= clientCommandTokens[3]
		lineTokens = server_file_reading.getLineWithString("protected.txt", filename, 0)
		if ( len(lineTokens) == 0):
			return BAD_CODE+DELIM+"File does not exist on the server"

		fileKey = lineTokens[1].strip()
		if ( fileKey != enteredKey ):
			return BAD_CODE+DELIM+"Incorrect file key"
		return GOOD_CODE+DELIM+"GET"

	else:
		return BAD_CODE+DELIM+"Invalid privacy option"
	
'''
Checks whether the POST command sent by the client is valid

Returns the COMMAND MESSAGE to be sent to the client
'''
def getPostCheckResponse( clientCommandTokens):
	if (len(clientCommandTokens)<3):
		return BAD_CODE+DELIM+"POST requires more parameters"

	filename = clientCommandTokens[2]
	privacy = clientCommandTokens[1]

	if (server_file_reading.isStringInFile("open.txt", filename)):
		return BAD_CODE+DELIM+"File already exists on the server. Try a different name"
		
	lineTokens = server_file_reading.getLineWithString("protected.txt", filename, 0)
	if ( len(lineTokens) != 0):
		return BAD_CODE+DELIM+"File already exists on the server. Try a different name"

	if (privacy == PUBLIC):
		if (len(clientCommandTokens) != 3):
			return BAD_CODE+DELIM+"Public POST requires 3 parameters"

		# elif (server_file_reading.isStringInFile("open.txt", filename)):
		# 	return BAD_CODE+DELIM+"File already exists on the server. Try a different name"
		else:
			return GOOD_CODE+DELIM+"POST"

	elif (privacy == PRIVATE):
		if (len(clientCommandTokens) != 4):
			return BAD_CODE+DELIM+"Private POST requires 4 parameters"

		# lineTokens = server_file_reading.getLineWithString("protected.txt", filename, 0)
		
		# if ( len(lineTokens) != 0):
		# 	return BAD_CODE+DELIM+"File already exists on the server. Try a different name"
		# else:
		return GOOD_CODE+DELIM+"POST"
	else:
		return BAD_CODE+DELIM+"Invalid privacy option"

'''
Checks whether the QUERY command sent by the client is valid

Returns the COMMAND MESSAGE to be sent to the client
'''
def getQueryCheckResponse(clientCommandTokens):
	if (len(clientCommandTokens)<2):
		return BAD_CODE+DELIM+"QUERY requires more parameters"
	
	option = clientCommandTokens[1]

	if (option == PUBLIC):
		if (len(clientCommandTokens)!=2):
			return BAD_CODE+DELIM+"Public QUERY requires 2 parameters"
		return GOOD_CODE+DELIM+"QUERY"

	elif (option == PRIVATE or option == PUBLIC_AND_PRIVATE):
		if (len(clientCommandTokens)!=3):
			return BAD_CODE+DELIM+"Private QUERY requires 3 parameters"

		enteredKey = clientCommandTokens[2]
		lineTokens = server_file_reading.getLineWithString("protected.txt", enteredKey, 1 )
		if (len(lineTokens) == 0):
			return BAD_CODE+DELIM+"Entered key applies to no files on the server"
		
		return GOOD_CODE+DELIM+"QUERY"
	
	else:
		return BAD_CODE+DELIM+"Invalid privacy option"
